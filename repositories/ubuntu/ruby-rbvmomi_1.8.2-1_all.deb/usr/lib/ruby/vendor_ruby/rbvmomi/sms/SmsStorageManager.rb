class RbVmomi::SMS::SmsStorageManager

  def RegisterProvider_Task2 providerSpec
     self.RegisterProvider_Task providerSpec
  end

end
