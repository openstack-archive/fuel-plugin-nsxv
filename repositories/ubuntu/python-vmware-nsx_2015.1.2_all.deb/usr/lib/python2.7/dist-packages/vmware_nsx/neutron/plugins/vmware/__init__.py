import os

from neutron.plugins.vmware import extensions

NSX_EXT_PATH = os.path.dirname(extensions.__file__)
